package com.smartbank.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.smartbank.model.Account;
import com.smartbank.model.User;
import com.smartbank.dao.UserDao;
import com.smartbank.service.UserService;
 


	

@Controller

public class UserController {

	@Autowired
	private UserService userService;


	@RequestMapping("login")
	public String login(Model m)
	{
		
		m.addAttribute("userBean", new User());
		return "login";
	}




@RequestMapping("Validate")
public String Validate(@Valid @ModelAttribute("userBean")User userBean,BindingResult result,Model m) throws Exception
{
	
	String result=userService.validate(userBean);
		if(result.equals("success"))
		{
			return "Success";
	
		}
		else
		{
			m.addAttribute("user",userBean);
	        return "failure";
		}
		
		 
	     
	
	
	

}
}











