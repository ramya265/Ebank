package com.smartbank.dao;
import java.util.List;
import java.util.Random;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import com.smartbank.model.Account;
import com.smartbank.model.Customer;

//import com.pack.model.User;
public class CustomerDAO {
@Autowired
private SessionFactory sessionFactory;

public long addCustomer(Customer customer,Account  account) {
	Random r=new Random();
	Session session =sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	long num=(long)r.nextInt(100000000);
			Long acc=(long)r.nextInt(1000);
	String acno="54769955234"+acc.toString();
	System.out.println("ano"+num);
	customer.setId(num);
	account.setCustId(customer);
	account.setAccNo(Long.parseLong(acno));
	account.setAccType(accType);
	long i=(long) session.save(account);
	tx.commit();
	session.close();
	return i;
	
	
	
}
}
