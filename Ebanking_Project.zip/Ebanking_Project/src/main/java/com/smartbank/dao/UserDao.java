package com.smartbank.dao;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.model.User;


public class UserDao {
	@Autowired
	private	 SessionFactory sessionFactory;
	 
	public String validate(User userBean) throws Exception
	{
		Session session = sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		
		String q="from User where uname=:unam and pwd=:pWd";
		Query que=session.createQuery(q);
		que.setParameter("unam",userBean.getUname());
		que.setParameter("pWd",userBean.getPwd());
		List<String> res=que.getResultList();
		if((res!=null)&&(res.size()>0))
			return "Success";
		else
			
			return "failure";
		
	}
	 
	
	  	         
	}

	



