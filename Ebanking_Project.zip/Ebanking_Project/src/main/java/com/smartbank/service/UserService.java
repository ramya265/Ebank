package com.smartbank.service;

import com.smartbank.dao.UserDao;
import com.smartbank.model.User;
import org.springframework.beans.factory.annotation.Autowired;

	



	public class UserService {
		
		@Autowired
		private UserDao userDAO;
	 


			 
			public void addUser(User user) {
				  userDAO.addUser(user);  
				
			}
			String loginCheck(String uName,String passWord);
			public List<account> getAccount(int accountId);
			
			
			
			
			
	}








