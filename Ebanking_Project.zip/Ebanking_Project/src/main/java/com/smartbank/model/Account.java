package com.smartbank.model;


	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;
	 
	 

	import javax.persistence.CascadeType;
	 

	 

	@Entity
	@Table(name="Account")

	public class Account {
		
		//CustIdnumber(10),accNo number(15),accTypevarchar(25)
		
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		  @Column(name="accNo")
		private long accNo;
		public long getAccNo()
		{
			return accNo;
		
		}
		public void setAccNo(long accNo)
		{
			this.accNo=accNo;
		}
		 @Column(name="accType")
		 private String accType;
		public String getAccType()
		{
			return accType;
		
		}
		public void setAccType(String accType )
		{
			this.accType=accType;
		}
		//@ManyToOne(cascade=CascadeType.ALL)
		//@JoinColumn(name="custId",unique=true)
		
		private Customer custId;
		public Customer getCustId() {
			return custId;
		}
		public void setCustId(Customer custId)
		{
			this.custId=custId;
		}
		
		
		
	}














