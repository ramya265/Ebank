package com.smartbank.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
 
 

import javax.persistence.CascadeType;
 
@Entity
@Table(name="Customer")
public class Customer {
	private long id;
	public long getId()
	{
		return id;
	}
public void setId(long id) { 
	this.id=id;
}
private int age;
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age=age;
}
private String gender;
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender=gender;
}
private String city;
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city=city;
}
private String occupation;
public String getOccupation() {
	return occupation;
}
public void setOccupation(String occpation) {
	this.occupation=occupation;
}
private int cno ;
public int getcontactNo() {
	return cno;
}
public void setcontactNo(int cno) {
	this.cno=cno;
}
}
